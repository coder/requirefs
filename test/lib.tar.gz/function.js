const fn = require("./module.exports.js");
module.exports = {
  test: "test",
  fn: fn()
};
