exports = { qux: "exports" }
module.exports = { qux: "module.exports" }
