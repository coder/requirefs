module.exports = { qux: "module.exports" }
