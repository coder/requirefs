module.exports = function () {
  return "function";
};
