const t = require("./circular");

exports.ralucric = () => {
  return t.circular;
};
