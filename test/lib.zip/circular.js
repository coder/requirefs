const t = require("./ralucric");

exports.circular = "hello";
exports.ralucric = t.ralucric();
