"use strict";
exports = {
    obi: "Why, hello there!",
};
